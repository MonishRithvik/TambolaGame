# Tambola Game Application

## Overview

This is a modern web-based Tambola (Bingo) game application built with React, Express, and TypeScript. The application provides a complete digital Tambola experience with features like ticket generation, number calling, voice announcements, and win detection. Players can generate multiple tickets, mark numbers as they are called, and the system automatically detects various winning patterns including Jaldi 5, line completions, and full house.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management with custom hooks for game logic
- **UI Framework**: Shadcn/ui components with Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with custom dark theme optimized for gaming experience
- **Animations**: Framer Motion for smooth animations and transitions
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules for modern JavaScript features
- **API Design**: RESTful API with JSON responses
- **Data Storage**: In-memory storage with interface-based design for easy database migration
- **Session Management**: UUID-based session identification
- **Development**: Hot module replacement with Vite integration in development mode

### Component Design
- **Modular Components**: Each game feature (current number display, number grid, tickets) is a separate component
- **Custom Hooks**: Game state management abstracted into reusable hooks
- **Responsive Design**: Mobile-first approach with responsive grid layouts
- **Accessibility**: ARIA labels and semantic HTML throughout

### Game Logic Architecture
- **Ticket Generation**: Algorithm generates valid 3x9 Tambola tickets with proper number distribution
- **Win Detection**: Automated checking for Jaldi 5, line completions, and full house patterns
- **Number Management**: Random number selection from 1-90 with duplicate prevention
- **Voice Integration**: Web Speech API integration with fallback handling

### Data Flow
- **Client-Server Communication**: RESTful API calls with optimistic updates
- **Real-time Updates**: Polling-based updates for game state synchronization
- **Error Handling**: Comprehensive error boundaries and user feedback
- **Caching Strategy**: React Query handles caching and background refetching

## External Dependencies

### Core Framework Dependencies
- **@tanstack/react-query**: Server state management and caching
- **express**: Web application framework for the backend
- **react**: Frontend framework with hooks and modern patterns
- **typescript**: Type safety across the entire application
- **vite**: Build tool and development server

### UI and Styling
- **@radix-ui/react-***: Accessible, unstyled UI primitives for components
- **tailwindcss**: Utility-first CSS framework for styling
- **framer-motion**: Animation library for smooth UI transitions
- **lucide-react**: Modern icon library with consistent styling

### Database and ORM
- **drizzle-orm**: Type-safe SQL ORM with PostgreSQL support
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-kit**: Database migration and schema management tools

### Development Tools
- **@replit/vite-plugin-runtime-error-modal**: Development error handling
- **@replit/vite-plugin-cartographer**: Development tooling for Replit environment
- **tsx**: TypeScript execution for development server

### Form and Validation
- **@hookform/resolvers**: Form validation resolvers
- **drizzle-zod**: Zod schema generation from Drizzle schemas
- **zod**: Runtime type validation and schema definition

### Additional Features
- **date-fns**: Date manipulation utilities
- **nanoid**: Unique ID generation for sessions
- **clsx** and **tailwind-merge**: Dynamic CSS class management