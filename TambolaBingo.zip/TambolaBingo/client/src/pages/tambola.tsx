import { useEffect } from "react";
import { motion } from "framer-motion";
import { useGameState } from "@/hooks/useGameState";
import { useSpeech } from "@/hooks/useSpeech";
import CurrentNumberDisplay from "@/components/CurrentNumberDisplay";
import NumberGrid from "@/components/NumberGrid";
import TambolaTicket from "@/components/TambolaTicket";
import TicketGenerator from "@/components/TicketGenerator";
import GameStats from "@/components/GameStats";
import WinModal from "@/components/WinModal";
import VoiceIndicator from "@/components/VoiceIndicator";
import { Button } from "@/components/ui/button";
import { Gamepad, VolumeX, Volume2, RotateCcw } from "lucide-react";

export default function TambolaGame() {
  const {
    gameSession,
    tickets,
    pickNumber,
    resetGame,
    toggleVoice,
    generateTicket,
    markTicketNumber,
    winCondition,
    clearWinCondition,
    isLoading,
    isGenerating
  } = useGameState();

  const { isSupported, speak, isSpeaking } = useSpeech();

  useEffect(() => {
    if (gameSession?.currentNumber && gameSession.voiceEnabled && isSupported) {
      speak(gameSession.currentNumber.toString());
    }
  }, [gameSession?.currentNumber, gameSession?.voiceEnabled, isSupported, speak]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading game...</div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-violet-900 via-purple-900 to-indigo-900 font-sans text-white min-h-screen touch-manipulation">
      {/* Header */}
      <header className="bg-gradient-to-r from-purple-800/80 via-pink-700/80 to-purple-800/80 backdrop-blur-sm border-b-4 border-purple-400/50 p-6 shadow-2xl">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center space-x-4">
            <motion.div
              initial={{ rotate: -180, scale: 0 }}
              animate={{ rotate: 0, scale: 1 }}
              transition={{ duration: 0.8, ease: "backOut" }}
            >
              <Gamepad className="text-yellow-400 text-5xl drop-shadow-2xl animate-glow" />
            </motion.div>
            <motion.h1 
              className="text-5xl font-black bg-gradient-to-r from-yellow-400 via-pink-400 to-purple-400 bg-clip-text text-transparent drop-shadow-2xl animate-float"
              initial={{ x: -100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              Smart Tambola
            </motion.h1>
          </div>
          <div className="flex items-center space-x-4">
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                onClick={toggleVoice}
                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-400 hover:to-blue-500 border-2 border-blue-400 px-8 py-4 font-black text-lg rounded-2xl shadow-2xl shadow-blue-500/30 touch-manipulation"
                data-testid="button-toggle-voice"
              >
                {gameSession?.voiceEnabled ? (
                  <>
                    <Volume2 className="mr-2 h-5 w-5" />
                    Voice ON
                  </>
                ) : (
                  <>
                    <VolumeX className="mr-2 h-5 w-5" />
                    Voice OFF
                  </>
                )}
              </Button>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                onClick={resetGame}
                className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-400 hover:to-red-500 border-2 border-red-400 px-8 py-4 font-black text-lg rounded-2xl shadow-2xl shadow-red-500/30 touch-manipulation"
                data-testid="button-reset-game"
              >
                <RotateCcw className="mr-2 h-5 w-5" />
                Reset Game
              </Button>
            </motion.div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-4 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Game Area */}
        <div className="lg:col-span-2 space-y-6">
          <CurrentNumberDisplay
            currentNumber={gameSession?.currentNumber || null}
            onPickNumber={pickNumber}
          />
          
          <NumberGrid
            calledNumbers={gameSession?.calledNumbers || []}
          />
          
          <div className="bg-slate-800 border-2 border-slate-600 p-4">
            <h3 className="text-lg font-semibold mb-4 text-slate-300">Called Numbers History</h3>
            <div className="flex flex-wrap gap-2" data-testid="called-numbers-history">
              {gameSession?.calledNumbers?.map((number) => (
                <span
                  key={number}
                  className="bg-green-600 border-2 border-green-500 px-3 py-1 text-sm font-semibold animate-bounce-in"
                  data-testid={`called-number-${number}`}
                >
                  {number}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Side Panel */}
        <div className="space-y-6">
          <TicketGenerator 
            onGenerateTicket={generateTicket}
            isGenerating={isGenerating}
          />
          
          {tickets.map((ticket) => (
            <TambolaTicket
              key={ticket.id}
              ticket={ticket}
              calledNumbers={gameSession?.calledNumbers || []}
              onMarkNumber={markTicketNumber}
            />
          ))}
          
          <GameStats
            gameSession={gameSession || null}
            ticketCount={tickets.length}
          />
        </div>
      </main>

      {/* Win Modal */}
      {winCondition && (
        <WinModal
          winType={winCondition.type}
          message={winCondition.message}
          onClose={clearWinCondition}
        />
      )}

      {/* Voice Indicator */}
      <VoiceIndicator isVisible={isSpeaking && Boolean(gameSession?.voiceEnabled)} />
    </div>
  );
}
