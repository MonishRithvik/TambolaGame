import { Button } from "@/components/ui/button";
import { Dice1 } from "lucide-react";
import { motion } from "framer-motion";

interface CurrentNumberDisplayProps {
  currentNumber: number | null;
  onPickNumber: () => void;
}

export default function CurrentNumberDisplay({ currentNumber, onPickNumber }: CurrentNumberDisplayProps) {
  return (
    <div className="bg-gradient-to-br from-slate-800 to-slate-900 border-4 border-amber-500 p-8 text-center shadow-2xl">
      <h2 className="text-2xl font-bold mb-6 text-amber-400">Current Number</h2>
      <div className="relative mb-8" data-testid="current-number-display">
        <motion.div
          key={currentNumber}
          initial={{ scale: 0.3, opacity: 0, rotateY: 180 }}
          animate={{ scale: 1, opacity: 1, rotateY: 0 }}
          transition={{ 
            duration: 0.6, 
            ease: "easeOut",
            type: "spring",
            stiffness: 100
          }}
          className="text-8xl font-black text-amber-400 drop-shadow-lg"
          style={{
            textShadow: "0 0 20px rgba(251, 191, 36, 0.6)"
          }}
        >
          {currentNumber || "--"}
        </motion.div>
        {currentNumber && (
          <motion.div 
            className="absolute inset-0 border-4 border-amber-400 opacity-30"
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.1, 0.3]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        )}
      </div>
      <Button
        onClick={onPickNumber}
        className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-900 px-10 py-4 font-black text-xl border-4 border-amber-400 shadow-lg hover:shadow-amber-500/50 transition-all duration-200"
        data-testid="button-pick-number"
      >
        <Dice1 className="mr-3 h-6 w-6" />
        Pick Number
      </Button>
    </div>
  );
}
