import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Ticket, Plus } from "lucide-react";

interface TicketGeneratorProps {
  onGenerateTicket: () => void;
  isGenerating: boolean;
}

export default function TicketGenerator({ onGenerateTicket, isGenerating }: TicketGeneratorProps) {
  return (
    <motion.div 
      className="bg-gradient-to-br from-emerald-900/50 to-teal-900/50 backdrop-blur-sm border-2 border-emerald-500/30 p-8 rounded-3xl shadow-2xl text-center"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, ease: "backOut" }}
    >
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        <Ticket className="text-emerald-400 text-6xl mx-auto mb-6 drop-shadow-2xl animate-glow" />
        <h2 className="text-3xl font-black mb-4 bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 bg-clip-text text-transparent">
          Generate Tambola Tickets
        </h2>
        <p className="text-emerald-200 mb-8 text-lg">
          Create authentic 3x9 Tambola tickets with proper number distribution
        </p>
      </motion.div>

      <motion.div
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Button
          onClick={onGenerateTicket}
          disabled={isGenerating}
          className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white px-12 py-6 text-xl font-black rounded-2xl shadow-2xl shadow-emerald-500/30 border-2 border-emerald-400 touch-manipulation"
          data-testid="button-generate-ticket"
        >
          {isGenerating ? (
            <>
              <motion.div
                className="w-6 h-6 border-3 border-white border-t-transparent rounded-full mr-3"
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              />
              Generating...
            </>
          ) : (
            <>
              <Plus className="mr-3 h-6 w-6" />
              Generate New Ticket
            </>
          )}
        </Button>
      </motion.div>
    </motion.div>
  );
}