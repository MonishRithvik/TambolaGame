import { type TambolaTicket } from "@shared/schema";
import { checkJaldi5, checkLines, checkFullHouse } from "@/lib/tambola";
import { motion } from "framer-motion";

interface TambolaTicketProps {
  ticket: TambolaTicket;
  calledNumbers: number[];
  onMarkNumber: (ticketId: string, number: number) => void;
}

export default function TambolaTicket({ ticket, calledNumbers, onMarkNumber }: TambolaTicketProps) {
  const grid = ticket.grid as (number | null)[][];
  const markedNumbers = ticket.markedNumbers || [];

  const getCorrectMarks = () => {
    return markedNumbers.filter(num => calledNumbers.includes(num));
  };

  const getIncorrectMarks = () => {
    return markedNumbers.filter(num => !calledNumbers.includes(num));
  };

  const jaldi5Count = getCorrectMarks().length >= 5 ? 5 : getCorrectMarks().length;
  const completedLines = checkLines(grid, getCorrectMarks());
  const isFullHouse = checkFullHouse(grid, getCorrectMarks());

  const handleCellClick = (number: number) => {
    onMarkNumber(ticket.id, number);
  };

  const getCellClasses = (number: number | null) => {
    if (!number) return "w-12 h-12 border-2 border-slate-700 bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg";
    
    const isMarked = markedNumbers.includes(number);
    const isCalled = calledNumbers.includes(number);
    
    if (isMarked) {
      if (isCalled) {
        return "w-12 h-12 border-2 border-green-400 bg-gradient-to-br from-green-400 via-green-500 to-green-600 rounded-lg flex items-center justify-center text-sm font-black text-white cursor-pointer hover:from-green-300 hover:via-green-400 hover:to-green-500 transition-all duration-300 shadow-xl shadow-green-500/30 ring-2 ring-green-300/50 animate-glow";
      } else {
        return "w-12 h-12 border-2 border-red-400 bg-gradient-to-br from-red-400 via-red-500 to-red-600 rounded-lg flex items-center justify-center text-sm font-black text-white cursor-pointer hover:from-red-300 hover:via-red-400 hover:to-red-500 transition-all duration-300 shadow-xl shadow-red-500/30 ring-2 ring-red-300/50 animate-shake";
      }
    }
    
    return "w-12 h-12 border-2 border-slate-400 bg-gradient-to-br from-slate-200 via-slate-100 to-white rounded-lg flex items-center justify-center text-sm font-black text-slate-800 cursor-pointer hover:from-purple-200 hover:via-purple-100 hover:to-purple-50 hover:border-purple-400 transition-all duration-300 shadow-lg hover:shadow-xl hover:shadow-purple-500/20";
  };

  return (
    <motion.div 
      className="bg-gradient-to-br from-purple-900/50 to-indigo-900/50 backdrop-blur-sm border-2 border-purple-400/30 p-6 rounded-3xl shadow-2xl"
      initial={{ opacity: 0, scale: 0.8, y: 50 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ duration: 0.8, ease: "backOut" }}
      whileHover={{ scale: 1.02, rotateY: 2 }}
    >
      <motion.h3 
        className="text-xl font-black mb-6 bg-gradient-to-r from-purple-400 via-pink-400 to-orange-400 bg-clip-text text-transparent"
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        Ticket #{ticket.ticketNumber}
      </motion.h3>
      
      <div className="bg-gradient-to-br from-white via-purple-50 to-pink-50 p-6 rounded-2xl border-2 border-purple-200 shadow-xl">
        <div className="text-center mb-4">
          <motion.h4 
            className="text-slate-800 font-black text-lg bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent"
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            TAMBOLA TICKET #{String(ticket.ticketNumber).padStart(3, '0')}
          </motion.h4>
        </div>
        
        <div className="grid grid-cols-9 gap-1 border-4 border-slate-800 rounded-xl overflow-hidden shadow-2xl" data-testid={`ticket-grid-${ticket.id}`}>
          {grid.flat().map((number, index) => (
            <motion.div
              key={index}
              whileTap={number ? { scale: 0.9 } : {}}
              whileHover={number ? { 
                scale: 1.15, 
                rotateZ: 5,
                boxShadow: markedNumbers.includes(number!)
                  ? calledNumbers.includes(number!)
                    ? "0 15px 30px rgba(34, 197, 94, 0.6)"
                    : "0 15px 30px rgba(239, 68, 68, 0.6)"
                  : "0 10px 20px rgba(168, 85, 247, 0.4)"
              } : {}}
              className={getCellClasses(number)}
              onClick={() => number && handleCellClick(number)}
              data-testid={number ? `ticket-number-${number}` : `ticket-empty-${index}`}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ 
                delay: index * 0.01,
                duration: 0.3,
                ease: "backOut"
              }}
            >
              <span className="drop-shadow-sm">{number}</span>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="mt-6 p-4 bg-gradient-to-r from-slate-100 via-purple-50 to-pink-50 border-2 border-purple-200 rounded-xl shadow-lg"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <div className="grid grid-cols-3 gap-4 text-sm">
            <motion.div 
              className="text-center"
              data-testid="jaldi5-status"
              whileHover={{ scale: 1.05 }}
            >
              <div className={`font-black text-lg ${jaldi5Count >= 5 ? 'text-green-600 animate-bounce' : 'text-orange-600'}`}>
                {jaldi5Count >= 5 ? '⚡ JALDI 5!' : `Jaldi 5: ${jaldi5Count}/5`}
              </div>
              {jaldi5Count >= 5 && <div className="text-green-600 text-sm font-bold animate-pulse">COMPLETED!</div>}
            </motion.div>
            <motion.div 
              className="text-center"
              data-testid="lines-status"
              whileHover={{ scale: 1.05 }}
            >
              <div className={`font-black text-lg ${completedLines > 0 ? 'text-blue-600 animate-bounce' : 'text-slate-600'}`}>
                {completedLines > 0 ? `🎯 ${completedLines} LINE${completedLines > 1 ? 'S' : ''}!` : `Lines: ${completedLines}/3`}
              </div>
              {completedLines > 0 && <div className="text-blue-600 text-sm font-bold animate-pulse">COMPLETED!</div>}
            </motion.div>
            <motion.div 
              className="text-center"
              data-testid="fullhouse-status"
              whileHover={{ scale: 1.05 }}
            >
              <div className={`font-black text-lg ${isFullHouse ? 'text-purple-600 animate-bounce' : 'text-slate-600'}`}>
                {isFullHouse ? '🏆 FULL HOUSE!' : `House: ${getCorrectMarks().length}/15`}
              </div>
              {isFullHouse && <div className="text-purple-600 text-sm font-bold animate-pulse">COMPLETED!</div>}
            </motion.div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
