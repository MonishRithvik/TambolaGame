import { motion } from "framer-motion";

interface NumberGridProps {
  calledNumbers: number[];
}

export default function NumberGrid({ calledNumbers }: NumberGridProps) {
  const numbers = Array.from({ length: 90 }, (_, i) => i + 1);

  return (
    <motion.div 
      className="bg-gradient-to-br from-purple-900/50 to-indigo-900/50 backdrop-blur-sm border-2 border-purple-500/30 p-8 rounded-3xl shadow-2xl"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <motion.h3 
        className="text-2xl font-black mb-8 bg-gradient-to-r from-purple-400 via-pink-400 to-orange-400 bg-clip-text text-transparent text-center animate-glow"
        initial={{ scale: 0.8 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        All Numbers (1-90)
      </motion.h3>
      <div className="grid grid-cols-10 gap-3" data-testid="number-grid">
        {numbers.map((number) => {
          const isCalled = calledNumbers.includes(number);
          
          return (
            <motion.div
              key={number}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ 
                opacity: 1, 
                scale: 1,
                ...(isCalled ? { 
                  rotate: [0, 10, -10, 0],
                  backgroundColor: ['#fbbf24', '#f59e0b', '#fbbf24']
                } : {})
              }}
              transition={{ 
                duration: isCalled ? 0.8 : 0.3,
                delay: number * 0.005,
                ease: "backOut"
              }}
              className={`
                aspect-square rounded-2xl flex items-center justify-center text-lg font-black cursor-pointer transition-all duration-500 transform
                ${isCalled 
                  ? 'bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 text-slate-900 shadow-2xl shadow-yellow-500/50 animate-glow ring-4 ring-yellow-300/50' 
                  : 'bg-gradient-to-br from-slate-600 via-slate-700 to-slate-800 text-white hover:from-purple-600 hover:via-purple-700 hover:to-purple-800 hover:shadow-xl hover:shadow-purple-500/30 border-2 border-slate-500 hover:border-purple-400'
                }
              `}
              data-testid={`number-grid-${number}`}
              data-number={number}
              whileHover={{ 
                scale: 1.1, 
                rotateZ: 5,
                boxShadow: isCalled 
                  ? "0 20px 40px rgba(251, 191, 36, 0.6)" 
                  : "0 15px 30px rgba(168, 85, 247, 0.4)"
              }}
              whileTap={{ scale: 0.9 }}
            >
              <span className="select-none drop-shadow-lg">{number}</span>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
