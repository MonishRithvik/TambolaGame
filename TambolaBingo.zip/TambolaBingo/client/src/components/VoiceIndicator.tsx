import { Volume2 } from "lucide-react";
import { motion } from "framer-motion";

interface VoiceIndicatorProps {
  isVisible: boolean;
}

export default function VoiceIndicator({ isVisible }: VoiceIndicatorProps) {
  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed bottom-4 right-4 bg-blue-600 border-2 border-blue-500 p-3"
      data-testid="voice-indicator"
    >
      <div className="flex items-center text-white">
        <motion.div
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 1, repeat: Infinity }}
        >
          <Volume2 className="text-xl mr-2" />
        </motion.div>
        <span className="font-semibold">Speaking...</span>
      </div>
    </motion.div>
  );
}
