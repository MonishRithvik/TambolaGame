import { type GameSession } from "@shared/schema";

interface GameStatsProps {
  gameSession: GameSession | null;
  ticketCount: number;
}

export default function GameStats({ gameSession, ticketCount }: GameStatsProps) {
  const numbersCalledCount = gameSession?.calledNumbers?.length || 0;
  const numbersRemainingCount = 90 - numbersCalledCount;

  return (
    <div className="bg-slate-800 border-2 border-slate-600 p-4">
      <h3 className="text-lg font-semibold mb-4 text-slate-300">Game Statistics</h3>
      <div className="space-y-3">
        <div className="flex justify-between">
          <span className="text-slate-400">Numbers Called:</span>
          <span className="font-semibold text-white" data-testid="numbers-called-count">
            {numbersCalledCount}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-400">Remaining:</span>
          <span className="font-semibold text-white" data-testid="numbers-remaining-count">
            {numbersRemainingCount}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-400">Active Tickets:</span>
          <span className="font-semibold text-white" data-testid="active-tickets-count">
            {ticketCount}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-400">Voice Enabled:</span>
          <span 
            className={`font-semibold ${gameSession?.voiceEnabled ? 'text-green-400' : 'text-red-400'}`}
            data-testid="voice-enabled-status"
          >
            {gameSession?.voiceEnabled ? 'YES' : 'NO'}
          </span>
        </div>
      </div>
    </div>
  );
}
