import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Trophy } from "lucide-react";

interface WinModalProps {
  winType: string;
  message: string;
  onClose: () => void;
}

export default function WinModal({ winType, message, onClose }: WinModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50" data-testid="win-modal">
      <motion.div
        initial={{ scale: 0.3, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.3, opacity: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="bg-slate-800 border-4 border-yellow-400 p-8 max-w-md mx-4"
      >
        <div className="text-center">
          <motion.div
            animate={{ 
              rotate: [0, -10, 10, -10, 0],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              duration: 1,
              repeat: Infinity,
              repeatDelay: 2
            }}
          >
            <Trophy className="text-yellow-400 text-6xl mb-4 mx-auto" />
          </motion.div>
          <h2 className="text-3xl font-bold text-yellow-400 mb-2" data-testid="win-type">
            {winType}
          </h2>
          <p className="text-xl text-white mb-4">Congratulations!</p>
          <p className="text-slate-300 mb-6" data-testid="win-message">
            {message}
          </p>
          <Button
            onClick={onClose}
            className="bg-yellow-500 hover:bg-yellow-600 text-slate-900 px-6 py-3 font-bold border-2 border-yellow-400"
            data-testid="button-close-win-modal"
          >
            Continue Playing
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
