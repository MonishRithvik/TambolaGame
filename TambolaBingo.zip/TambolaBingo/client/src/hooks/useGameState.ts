import { useState, useCallback, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { type GameSession, type TambolaTicket } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { generateTambolaTicket, checkJaldi5, checkLines, checkFullHouse } from "@/lib/tambola";
import { useToast } from "@/hooks/use-toast";

interface WinCondition {
  type: string;
  message: string;
}

export function useGameState() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [winCondition, setWinCondition] = useState<WinCondition | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Initialize game session
  const { data: gameSession, isLoading } = useQuery({
    queryKey: ["/api/game/session", sessionId],
    enabled: !!sessionId,
    staleTime: 0,
  });

  // Get tickets for session
  const { data: tickets = [] } = useQuery({
    queryKey: ["/api/tickets/session", sessionId],
    enabled: !!sessionId,
    staleTime: 0,
  });

  // Create initial session if none exists
  const createSessionMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/game/session", { voiceEnabled: true });
      return response.json();
    },
    onSuccess: (session: GameSession) => {
      setSessionId(session.id);
      queryClient.invalidateQueries({ queryKey: ["/api/game/session"] });
    },
  });

  // Update session mutation
  const updateSessionMutation = useMutation({
    mutationFn: async (updates: Partial<GameSession>) => {
      if (!sessionId) return null;
      const response = await apiRequest("PATCH", `/api/game/session/${sessionId}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/game/session", sessionId] });
    },
  });

  // Create ticket mutation
  const createTicketMutation = useMutation({
    mutationFn: async (ticketData: { ticketNumber: number; grid: (number | null)[][] }) => {
      if (!sessionId) return null;
      const response = await apiRequest("POST", "/api/tickets", {
        sessionId,
        ...ticketData,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets/session", sessionId] });
    },
  });

  // Update ticket marks mutation
  const updateTicketMutation = useMutation({
    mutationFn: async ({ ticketId, markedNumbers }: { ticketId: string; markedNumbers: number[] }) => {
      const response = await apiRequest("PATCH", `/api/tickets/${ticketId}/marks`, { markedNumbers });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets/session", sessionId] });
    },
  });

  // Initialize session on mount
  useEffect(() => {
    if (!sessionId && !createSessionMutation.isPending) {
      createSessionMutation.mutate();
    }
  }, []);

  // Type the gameSession and tickets properly
  const typedGameSession = gameSession as GameSession | undefined;
  const typedTickets = tickets as TambolaTicket[];

  const pickNumber = useCallback(() => {
    if (!typedGameSession) return;

    const calledNumbers = typedGameSession.calledNumbers || [];
    const availableNumbers = [];
    
    for (let i = 1; i <= 90; i++) {
      if (!calledNumbers.includes(i)) {
        availableNumbers.push(i);
      }
    }

    if (availableNumbers.length === 0) {
      toast({
        title: "Game Complete",
        description: "All numbers have been called!",
      });
      return;
    }

    const randomIndex = Math.floor(Math.random() * availableNumbers.length);
    const newNumber = availableNumbers[randomIndex];
    const newCalledNumbers = [...calledNumbers, newNumber];

    updateSessionMutation.mutate({
      currentNumber: newNumber,
      calledNumbers: newCalledNumbers,
    });
  }, [typedGameSession, updateSessionMutation, toast]);

  const resetGame = useCallback(() => {
    if (!sessionId) return;

    updateSessionMutation.mutate({
      calledNumbers: [],
      currentNumber: null,
      isActive: true,
    });

    // Clear all ticket marks
    typedTickets.forEach((ticket) => {
      updateTicketMutation.mutate({
        ticketId: ticket.id,
        markedNumbers: [],
      });
    });

    setWinCondition(null);
  }, [sessionId, updateSessionMutation, updateTicketMutation, typedTickets]);

  const toggleVoice = useCallback(() => {
    if (!typedGameSession) return;

    updateSessionMutation.mutate({
      voiceEnabled: !typedGameSession.voiceEnabled,
    });
  }, [typedGameSession, updateSessionMutation]);

  const generateTicket = useCallback(() => {
    const grid = generateTambolaTicket();
    createTicketMutation.mutate({
      ticketNumber: typedTickets.length + 1,
      grid,
    });
  }, [createTicketMutation, typedTickets.length]);

  const generateTickets = useCallback((count: number) => {
    for (let i = 0; i < count; i++) {
      const grid = generateTambolaTicket();
      createTicketMutation.mutate({
        ticketNumber: typedTickets.length + i + 1,
        grid,
      });
    }
  }, [createTicketMutation, typedTickets.length]);

  const markTicketNumber = useCallback((ticketId: string, number: number) => {
    const ticket = typedTickets.find((t) => t.id === ticketId);
    if (!ticket) return;

    const currentMarks = ticket.markedNumbers || [];
    const isCurrentlyMarked = currentMarks.includes(number);
    
    const newMarkedNumbers = isCurrentlyMarked
      ? currentMarks.filter((n) => n !== number)
      : [...currentMarks, number];

    updateTicketMutation.mutate({
      ticketId,
      markedNumbers: newMarkedNumbers,
    });

    // Check win conditions
    setTimeout(() => {
      const calledNumbers = typedGameSession?.calledNumbers || [];
      const correctMarks = newMarkedNumbers.filter((n) => calledNumbers.includes(n));
      const grid = ticket.grid as (number | null)[][];

      // Check Jaldi 5
      if (correctMarks.length === 5 && !winCondition) {
        setWinCondition({
          type: "JALDI 5!",
          message: "You completed the first 5 numbers!"
        });
      }

      // Check Lines
      const completedLines = checkLines(grid, correctMarks);
      if (completedLines > 0 && !winCondition) {
        setWinCondition({
          type: `LINE COMPLETE!`,
          message: `You completed ${completedLines} line${completedLines > 1 ? 's' : ''}!`
        });
      }

      // Check Full House
      if (checkFullHouse(grid, correctMarks) && !winCondition) {
        setWinCondition({
          type: "FULL HOUSE!",
          message: "You completed the entire ticket!"
        });
      }
    }, 100);
  }, [typedTickets, updateTicketMutation, typedGameSession, winCondition]);

  const clearWinCondition = useCallback(() => {
    setWinCondition(null);
  }, []);

  return {
    gameSession: typedGameSession,
    tickets: typedTickets,
    pickNumber,
    resetGame,
    toggleVoice,
    generateTicket,
    generateTickets,
    markTicketNumber,
    winCondition,
    clearWinCondition,
    isLoading: isLoading || createSessionMutation.isPending,
    isGenerating: createTicketMutation.isPending,
  };
}
