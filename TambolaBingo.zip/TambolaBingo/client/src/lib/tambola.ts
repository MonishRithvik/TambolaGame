// Tambola ticket generation and validation utilities

export function generateTambolaTicket(): (number | null)[][] {
  // Create a 3x9 grid
  const grid: (number | null)[][] = Array(3).fill(null).map(() => Array(9).fill(null));
  
  // Column ranges: 1-10, 11-20, 21-30, ..., 81-90
  const columnRanges = Array(9).fill(null).map((_, i) => ({
    min: i * 10 + 1,
    max: i * 10 + 10
  }));

  // Generate numbers for each column
  for (let col = 0; col < 9; col++) {
    const { min, max } = columnRanges[col];
    const availableNumbers = Array.from({ length: max - min + 1 }, (_, i) => min + i);
    
    // Shuffle numbers
    for (let i = availableNumbers.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [availableNumbers[i], availableNumbers[j]] = [availableNumbers[j], availableNumbers[i]];
    }

    // Place 1-3 numbers per column (will be adjusted later)
    const numbersToPlace = Math.min(3, availableNumbers.length);
    const positions = [0, 1, 2].sort(() => Math.random() - 0.5).slice(0, numbersToPlace);
    
    positions.forEach((row, index) => {
      grid[row][col] = availableNumbers[index];
    });
  }

  // Ensure each row has exactly 5 numbers
  for (let row = 0; row < 3; row++) {
    const currentNumbers = grid[row].filter(n => n !== null).length;
    
    if (currentNumbers < 5) {
      // Add more numbers
      const emptyCols = grid[row].map((val, col) => val === null ? col : -1).filter(col => col !== -1);
      const neededNumbers = 5 - currentNumbers;
      
      for (let i = 0; i < neededNumbers && i < emptyCols.length; i++) {
        const col = emptyCols[i];
        const { min, max } = columnRanges[col];
        const availableNumbers = Array.from({ length: max - min + 1 }, (_, j) => min + j)
          .filter(num => !grid.flat().includes(num));
        
        if (availableNumbers.length > 0) {
          grid[row][col] = availableNumbers[Math.floor(Math.random() * availableNumbers.length)];
        }
      }
    } else if (currentNumbers > 5) {
      // Remove excess numbers
      const filledCols = grid[row].map((val, col) => val !== null ? col : -1).filter(col => col !== -1);
      const excessNumbers = currentNumbers - 5;
      
      for (let i = 0; i < excessNumbers; i++) {
        const colToEmpty = filledCols[Math.floor(Math.random() * filledCols.length)];
        grid[row][colToEmpty] = null;
        filledCols.splice(filledCols.indexOf(colToEmpty), 1);
      }
    }
  }

  return grid;
}

export function checkJaldi5(markedNumbers: number[], calledNumbers: number[]): boolean {
  const correctMarks = markedNumbers.filter(n => calledNumbers.includes(n));
  return correctMarks.length >= 5;
}

export function checkLines(grid: (number | null)[][], correctMarks: number[]): number {
  let completedLines = 0;
  
  for (let row = 0; row < 3; row++) {
    const rowNumbers = grid[row].filter((n): n is number => n !== null);
    const completedNumbers = rowNumbers.filter(n => correctMarks.includes(n));
    
    if (completedNumbers.length === rowNumbers.length) {
      completedLines++;
    }
  }
  
  return completedLines;
}

export function checkFullHouse(grid: (number | null)[][], correctMarks: number[]): boolean {
  const allNumbers = grid.flat().filter((n): n is number => n !== null);
  const completedNumbers = allNumbers.filter(n => correctMarks.includes(n));
  
  return completedNumbers.length === allNumbers.length;
}

export function validateTambolaTicket(grid: (number | null)[][]): boolean {
  // Check grid dimensions
  if (grid.length !== 3 || grid.some(row => row.length !== 9)) {
    return false;
  }

  // Check each row has exactly 5 numbers
  for (const row of grid) {
    const numberCount = row.filter(n => n !== null).length;
    if (numberCount !== 5) {
      return false;
    }
  }

  // Check column ranges
  for (let col = 0; col < 9; col++) {
    const min = col * 10 + 1;
    const max = col * 10 + 10;
    
    for (let row = 0; row < 3; row++) {
      const number = grid[row][col];
      if (number !== null && (number < min || number > max)) {
        return false;
      }
    }
  }

  // Check for duplicate numbers
  const allNumbers = grid.flat().filter((n): n is number => n !== null);
  const uniqueNumbers = new Set(allNumbers);
  if (allNumbers.length !== uniqueNumbers.size) {
    return false;
  }

  return true;
}
