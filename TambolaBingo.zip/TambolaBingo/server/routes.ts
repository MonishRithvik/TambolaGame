import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGameSessionSchema, insertTambolaTicketSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create new game session
  app.post("/api/game/session", async (req, res) => {
    try {
      const sessionData = insertGameSessionSchema.parse(req.body);
      const session = await storage.createGameSession(sessionData);
      res.json(session);
    } catch (error) {
      res.status(400).json({ error: "Invalid session data" });
    }
  });

  // Get game session
  app.get("/api/game/session/:id", async (req, res) => {
    try {
      const session = await storage.getGameSession(req.params.id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to get session" });
    }
  });

  // Update game session (for number picking, etc.)
  app.patch("/api/game/session/:id", async (req, res) => {
    try {
      const session = await storage.updateGameSession(req.params.id, req.body);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to update session" });
    }
  });

  // Create tambola tickets
  app.post("/api/tickets", async (req, res) => {
    try {
      const ticketData = insertTambolaTicketSchema.parse(req.body);
      const ticket = await storage.createTambolaTicket(ticketData);
      res.json(ticket);
    } catch (error) {
      res.status(400).json({ error: "Invalid ticket data" });
    }
  });

  // Get tickets for a session
  app.get("/api/tickets/session/:sessionId", async (req, res) => {
    try {
      const tickets = await storage.getTicketsBySession(req.params.sessionId);
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ error: "Failed to get tickets" });
    }
  });

  // Update ticket marked numbers
  app.patch("/api/tickets/:id/marks", async (req, res) => {
    try {
      const { markedNumbers } = req.body;
      const ticket = await storage.updateTicketMarkedNumbers(req.params.id, markedNumbers);
      if (!ticket) {
        return res.status(404).json({ error: "Ticket not found" });
      }
      res.json(ticket);
    } catch (error) {
      res.status(500).json({ error: "Failed to update ticket" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
