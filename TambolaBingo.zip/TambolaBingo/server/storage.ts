import { type GameSession, type InsertGameSession, type TambolaTicket, type InsertTambolaTicket } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Game Session methods
  createGameSession(session: InsertGameSession): Promise<GameSession>;
  getGameSession(id: string): Promise<GameSession | undefined>;
  updateGameSession(id: string, updates: Partial<GameSession>): Promise<GameSession | undefined>;
  
  // Tambola Ticket methods
  createTambolaTicket(ticket: InsertTambolaTicket): Promise<TambolaTicket>;
  getTicketsBySession(sessionId: string): Promise<TambolaTicket[]>;
  updateTicketMarkedNumbers(id: string, markedNumbers: number[]): Promise<TambolaTicket | undefined>;
}

export class MemStorage implements IStorage {
  private gameSessions: Map<string, GameSession>;
  private tambolaTickets: Map<string, TambolaTicket>;

  constructor() {
    this.gameSessions = new Map();
    this.tambolaTickets = new Map();
  }

  async createGameSession(insertSession: InsertGameSession): Promise<GameSession> {
    const id = randomUUID();
    const session: GameSession = {
      id,
      calledNumbers: [],
      currentNumber: null,
      isActive: true,
      voiceEnabled: insertSession.voiceEnabled ?? true,
    };
    this.gameSessions.set(id, session);
    return session;
  }

  async getGameSession(id: string): Promise<GameSession | undefined> {
    return this.gameSessions.get(id);
  }

  async updateGameSession(id: string, updates: Partial<GameSession>): Promise<GameSession | undefined> {
    const session = this.gameSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...updates };
    this.gameSessions.set(id, updatedSession);
    return updatedSession;
  }

  async createTambolaTicket(insertTicket: InsertTambolaTicket): Promise<TambolaTicket> {
    const id = randomUUID();
    const ticket: TambolaTicket = {
      id,
      sessionId: insertTicket.sessionId || "",
      ticketNumber: insertTicket.ticketNumber,
      grid: insertTicket.grid as (number | null)[][],
      markedNumbers: [],
    };
    this.tambolaTickets.set(id, ticket);
    return ticket;
  }

  async getTicketsBySession(sessionId: string): Promise<TambolaTicket[]> {
    return Array.from(this.tambolaTickets.values()).filter(
      (ticket) => ticket.sessionId === sessionId,
    );
  }

  async updateTicketMarkedNumbers(id: string, markedNumbers: number[]): Promise<TambolaTicket | undefined> {
    const ticket = this.tambolaTickets.get(id);
    if (!ticket) return undefined;
    
    const updatedTicket = { ...ticket, markedNumbers };
    this.tambolaTickets.set(id, updatedTicket);
    return updatedTicket;
  }
}

export const storage = new MemStorage();
