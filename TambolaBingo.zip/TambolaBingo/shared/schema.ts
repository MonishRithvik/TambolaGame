import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const gameSession = pgTable("game_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  calledNumbers: jsonb("called_numbers").$type<number[]>().default([]),
  currentNumber: integer("current_number"),
  isActive: boolean("is_active").default(true),
  voiceEnabled: boolean("voice_enabled").default(true),
});

export const tambolaTicket = pgTable("tambola_tickets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").references(() => gameSession.id),
  ticketNumber: integer("ticket_number").notNull(),
  grid: jsonb("grid").$type<(number | null)[][]>().notNull(),
  markedNumbers: jsonb("marked_numbers").$type<number[]>().default([]),
});

export const insertGameSessionSchema = createInsertSchema(gameSession).pick({
  voiceEnabled: true,
});

export const insertTambolaTicketSchema = createInsertSchema(tambolaTicket).pick({
  sessionId: true,
  ticketNumber: true,
  grid: true,
});

export type InsertGameSession = z.infer<typeof insertGameSessionSchema>;
export type GameSession = typeof gameSession.$inferSelect;
export type InsertTambolaTicket = z.infer<typeof insertTambolaTicketSchema>;
export type TambolaTicket = typeof tambolaTicket.$inferSelect;
